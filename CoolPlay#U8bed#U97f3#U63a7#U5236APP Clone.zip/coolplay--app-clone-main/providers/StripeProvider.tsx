import React, { useState, useCallback, useMemo } from 'react';
import { Alert, Platform } from 'react-native';
import createContextHook from '@nkzw/create-context-hook';
import { useAuth } from './AuthProvider';

interface MembershipPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  interval: 'month' | 'year';
  features: string[];
  stripePriceId: string;
}

const MEMBERSHIP_PLANS: MembershipPlan[] = [
  {
    id: 'premium_monthly',
    name: 'Premium Monthly',
    price: 9.99,
    currency: 'USD',
    interval: 'month',
    stripePriceId: process.env.EXPO_PUBLIC_STRIPE_PREMIUM_MONTHLY_PRICE_ID || 'price_premium_monthly',
    features: [
      'Unlimited bookmarks',
      'Advanced categorization',
      'Priority support',
      'Ad-free experience',
      'Cloud sync',
    ],
  },
  {
    id: 'premium_yearly',
    name: 'Premium Yearly',
    price: 99.99,
    currency: 'USD',
    interval: 'year',
    stripePriceId: process.env.EXPO_PUBLIC_STRIPE_PREMIUM_YEARLY_PRICE_ID || 'price_premium_yearly',
    features: [
      'Unlimited bookmarks',
      'Advanced categorization',
      'Priority support',
      'Ad-free experience',
      'Cloud sync',
      'Save 17% vs monthly',
    ],
  },
  {
    id: 'pro_monthly',
    name: 'Pro Monthly',
    price: 19.99,
    currency: 'USD',
    interval: 'month',
    stripePriceId: process.env.EXPO_PUBLIC_STRIPE_PRO_MONTHLY_PRICE_ID || 'price_pro_monthly',
    features: [
      'Everything in Premium',
      'AI-powered recommendations',
      'Team collaboration',
      'Custom integrations',
      'API access',
    ],
  },
  {
    id: 'pro_yearly',
    name: 'Pro Yearly',
    price: 199.99,
    currency: 'USD',
    interval: 'year',
    stripePriceId: process.env.EXPO_PUBLIC_STRIPE_PRO_YEARLY_PRICE_ID || 'price_pro_yearly',
    features: [
      'Everything in Premium',
      'AI-powered recommendations',
      'Team collaboration',
      'Custom integrations',
      'API access',
      'Save 17% vs monthly',
    ],
  },
];

export const [StripeProvider, useStripe] = createContextHook(() => {
  const { user, profile, updateProfile } = useAuth();
  const [loading, setLoading] = useState<boolean>(false);

  const createCheckoutSession = useCallback(async (planId: string) => {
    if (!user) {
      Alert.alert('Error', 'Please sign in to subscribe');
      return null;
    }

    const plan = MEMBERSHIP_PLANS.find(p => p.id === planId);
    if (!plan) {
      Alert.alert('Error', 'Invalid plan selected');
      return null;
    }

    try {
      setLoading(true);

      const response = await fetch(`${process.env.EXPO_PUBLIC_API_URL}/api/stripe/create-checkout-session`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.id,
          priceId: plan.stripePriceId,
          successUrl: `${process.env.EXPO_PUBLIC_APP_URL}/subscription/success`,
          cancelUrl: `${process.env.EXPO_PUBLIC_APP_URL}/subscription/cancel`,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create checkout session');
      }

      const { sessionId, url } = await response.json();

      if (Platform.OS === 'web') {
        window.location.href = url;
      } else {
        Alert.alert(
          'Subscription',
          'Please visit the web version to complete your subscription',
          [{ text: 'OK' }]
        );
      }

      return sessionId;
    } catch (error) {
      console.error('Create checkout session error:', error);
      Alert.alert('Error', 'Failed to start subscription process');
      return null;
    } finally {
      setLoading(false);
    }
  }, [user]);

  const cancelSubscription = useCallback(async () => {
    if (!user || !profile) {
      Alert.alert('Error', 'No active subscription found');
      return false;
    }

    try {
      setLoading(true);

      const response = await fetch(`${process.env.EXPO_PUBLIC_API_URL}/api/stripe/cancel-subscription`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.id,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to cancel subscription');
      }

      await updateProfile({
        membership_tier: 'free',
        membership_expires_at: null,
      });

      Alert.alert('Success', 'Your subscription has been cancelled');
      return true;
    } catch (error) {
      console.error('Cancel subscription error:', error);
      Alert.alert('Error', 'Failed to cancel subscription');
      return false;
    } finally {
      setLoading(false);
    }
  }, [user, profile, updateProfile]);

  const getActivePlan = useCallback(() => {
    if (!profile || profile.membership_tier === 'free') return null;
    
    const isYearly = profile.membership_expires_at && 
      new Date(profile.membership_expires_at).getTime() - Date.now() > 180 * 24 * 60 * 60 * 1000;
    
    const planId = `${profile.membership_tier}_${isYearly ? 'yearly' : 'monthly'}`;
    return MEMBERSHIP_PLANS.find(p => p.id === planId) || null;
  }, [profile]);

  return useMemo(() => ({
    plans: MEMBERSHIP_PLANS,
    loading,
    createCheckoutSession,
    cancelSubscription,
    getActivePlan,
  }), [loading, createCheckoutSession, cancelSubscription, getActivePlan]);
});
