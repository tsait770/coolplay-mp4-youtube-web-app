import { useCallback, useMemo, useRef } from 'react';
import createContextHook from '@nkzw/create-context-hook';
// eslint-disable-next-line @rork/linters/rsp-no-asyncstorage-direct
import AsyncStorage from '@react-native-async-storage/async-storage';

// Safe JSON parsing utility
export const safeJsonParse = (data: string, fallback: any = null) => {
  try {
    if (!data || typeof data !== 'string') {
      console.log('[Storage] Invalid data type:', typeof data);
      return fallback;
    }
    
    const cleaned = data.trim();
    
    if (cleaned.length === 0) {
      console.log('[Storage] Empty data string');
      return fallback;
    }
    
    if (cleaned.includes('[object Object]') || 
        cleaned === 'undefined' || 
        cleaned === 'NaN' ||
        cleaned === 'null' ||
        cleaned.startsWith('object ') ||
        cleaned.startsWith('Object ')) {
      console.warn('[Storage] Detected corrupted data pattern:', cleaned.substring(0, 50));
      return fallback;
    }
    
    if (!cleaned.startsWith('{') && !cleaned.startsWith('[') && !cleaned.startsWith('"')) {
      console.warn('[Storage] Data does not start with valid JSON character:', cleaned.substring(0, 50));
      return fallback;
    }
    
    try {
      const parsed = JSON.parse(cleaned);
      
      if (parsed === null || parsed === undefined) {
        console.warn('[Storage] Parsed to null/undefined');
        return fallback;
      }
      
      return parsed;
    } catch (parseError: any) {
      console.error('[Storage] JSON parse error:', parseError?.message || parseError, 'Data preview:', cleaned.substring(0, 100));
      return fallback;
    }
  } catch (error: any) {
    console.error('[Storage] Unexpected error in safeJsonParse:', error?.message || error);
    return fallback;
  }
};

export const [StorageProvider, useStorage] = createContextHook(() => {
  const cache = useRef<Map<string, { data: string | null; timestamp: number }>>(new Map());
  const CACHE_TTL = 5000;
  
  const getItem = useCallback(async (key: string): Promise<string | null> => {
    try {
      if (!key || !key.trim()) {
        console.warn('[Storage] Invalid key provided to getItem');
        return null;
      }
      
      const trimmedKey = key.trim();
      const cached = cache.current.get(trimmedKey);
      if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.data;
      }
      
      const startTime = Date.now();
      const data = await AsyncStorage.getItem(trimmedKey);
      const duration = Date.now() - startTime;
      
      if (duration > 100) {
        console.warn(`[Storage] Slow getItem for key ${key}: ${duration}ms`);
      }
      
      cache.current.set(trimmedKey, { data, timestamp: Date.now() });
      
      if (data && typeof data === 'string' && data.length > 0) {
        const cleaned = data.trim();
        if (cleaned.includes('[object Object]') || 
            cleaned === 'undefined' || 
            cleaned === 'NaN' ||
            cleaned === 'null' ||
            cleaned.startsWith('object ') ||
            cleaned.startsWith('Object ')) {
          console.warn(`[Storage] Auto-clearing corrupted data for key: ${key}`);
          try {
            await AsyncStorage.removeItem(key.trim());
          } catch (removeError) {
            console.error(`[Storage] Failed to remove corrupted key ${key}:`, removeError);
          }
          return null;
        }
      }
      
      return data;
    } catch (error: any) {
      console.error(`[Storage] Failed to get item ${key}:`, error?.message || error);
      return null;
    }
  }, []);
  
  const invalidateCache = useCallback((key: string) => {
    cache.current.delete(key.trim());
  }, []);

  const setItem = useCallback(async (key: string, value: string): Promise<void> => {
    try {
      if (!key || !key.trim()) {
        console.error('[Storage] Invalid storage key');
        return;
      }
      if (value === null || value === undefined) {
        console.error('[Storage] Invalid storage value (null/undefined)');
        return;
      }
      
      if (typeof value === 'string') {
        if (value.includes('[object Object]') || 
            value === 'undefined' || 
            value === 'NaN' ||
            value === 'null' ||
            value.startsWith('object ') ||
            value.startsWith('Object ')) {
          console.error('[Storage] Attempting to save corrupted data, aborting:', value.substring(0, 50));
          return;
        }
        
        if (value.startsWith('{') || value.startsWith('[')) {
          try {
            JSON.parse(value);
          } catch {
            console.error('[Storage] Invalid JSON data, aborting save:', value.substring(0, 50));
            return;
          }
        }
      }
      
      const trimmedKey = key.trim();
      const startTime = Date.now();
      await AsyncStorage.setItem(trimmedKey, value);
      const duration = Date.now() - startTime;
      
      cache.current.set(trimmedKey, { data: value, timestamp: Date.now() });
      
      if (duration > 200) {
        console.warn(`[Storage] Slow setItem for key ${key}: ${duration}ms, size: ${value.length} bytes`);
      }
    } catch (error: any) {
      console.error(`[Storage] Failed to set item ${key}:`, error?.message || error);
    }
  }, []);

  const removeItem = useCallback(async (key: string): Promise<void> => {
    try {
      if (!key || !key.trim()) {
        console.error('Invalid storage key');
        return;
      }
      const trimmedKey = key.trim();
      cache.current.delete(trimmedKey);
      await AsyncStorage.removeItem(trimmedKey);
    } catch (error) {
      console.error(`Failed to remove item ${key}:`, error);
    }
  }, []);

  const clear = useCallback(async (): Promise<void> => {
    try {
      cache.current.clear();
      await AsyncStorage.clear();
    } catch (error) {
      console.error('Failed to clear storage:', error);
    }
  }, []);

  const clearCorruptedData = useCallback(async (): Promise<number> => {
    try {
      console.log('[Storage] Starting corrupted data scan...');
      const allKeys = await AsyncStorage.getAllKeys();
      const corruptedKeys: string[] = [];
      
      for (const key of allKeys) {
        try {
          const data = await AsyncStorage.getItem(key);
          if (data && typeof data === 'string' && data.length > 0) {
            const cleaned = data.trim();
            
            if (cleaned.includes('[object Object]') || 
                cleaned === 'undefined' || 
                cleaned === 'NaN' ||
                cleaned === 'null' ||
                cleaned.startsWith('object ') ||
                cleaned.startsWith('Object ')) {
              console.warn(`[Storage] Found corrupted key: ${key}`);
              corruptedKeys.push(key);
            } else if (cleaned.startsWith('{') || cleaned.startsWith('[')) {
              try {
                JSON.parse(cleaned);
              } catch {
                console.warn(`[Storage] Found invalid JSON key: ${key}`);
                corruptedKeys.push(key);
              }
            }
          }
        } catch (error: any) {
          console.error(`[Storage] Error checking key ${key}:`, error?.message || error);
        }
      }
      
      if (corruptedKeys.length > 0) {
        console.log(`[Storage] Clearing ${corruptedKeys.length} corrupted keys:`, corruptedKeys);
        await AsyncStorage.multiRemove(corruptedKeys);
      } else {
        console.log('[Storage] No corrupted data found');
      }
      
      return corruptedKeys.length;
    } catch (error: any) {
      console.error('[Storage] Failed to clear corrupted data:', error?.message || error);
      return 0;
    }
  }, []);

  return useMemo(() => ({
    getItem,
    setItem,
    removeItem,
    clear,
    clearCorruptedData,
    safeJsonParse,
    invalidateCache,
  }), [getItem, setItem, removeItem, clear, clearCorruptedData, invalidateCache]);
});