import { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { Check, Crown, Zap } from 'lucide-react-native';
import { useAuth } from '@/providers/AuthProvider';
import { useStripe } from '@/providers/StripeProvider';
import Colors from '@/constants/colors';

export default function SubscriptionScreen() {
  const router = useRouter();
  const { user, profile, isPremium } = useAuth();
  const { plans, loading, createCheckoutSession, cancelSubscription, getActivePlan } = useStripe();
  const [selectedInterval, setSelectedInterval] = useState<'month' | 'year'>('month');
  const activePlan = getActivePlan();

  const handleSubscribe = async (planId: string) => {
    if (!user) {
      Alert.alert('Sign In Required', 'Please sign in to subscribe', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign In', onPress: () => router.push('/auth/sign-in') },
      ]);
      return;
    }

    await createCheckoutSession(planId);
  };

  const handleCancelSubscription = () => {
    Alert.alert(
      'Cancel Subscription',
      'Are you sure you want to cancel your subscription? You will lose access to premium features at the end of your billing period.',
      [
        { text: 'Keep Subscription', style: 'cancel' },
        {
          text: 'Cancel Subscription',
          style: 'destructive',
          onPress: cancelSubscription,
        },
      ]
    );
  };

  const filteredPlans = plans.filter(p => p.interval === selectedInterval);

  return (
    <>
      <Stack.Screen options={{ title: 'Subscription', headerShown: true }} />
      <View style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <Crown size={48} color={Colors.primary.accent} />
            <Text style={styles.title}>Upgrade to Premium</Text>
            <Text style={styles.subtitle}>
              Unlock all features and get the most out of your bookmarks
            </Text>
          </View>

          {isPremium && activePlan && (
            <View style={styles.currentPlanCard}>
              <View style={styles.currentPlanHeader}>
                <Zap size={20} color={Colors.primary.accent} />
                <Text style={styles.currentPlanTitle}>Current Plan</Text>
              </View>
              <Text style={styles.currentPlanName}>{activePlan.name}</Text>
              <Text style={styles.currentPlanPrice}>
                ${activePlan.price}/{activePlan.interval}
              </Text>
              {profile?.membership_expires_at && (
                <Text style={styles.expiresText}>
                  Renews on {new Date(profile.membership_expires_at).toLocaleDateString()}
                </Text>
              )}
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={handleCancelSubscription}
                disabled={loading}
              >
                <Text style={styles.cancelButtonText}>Cancel Subscription</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.intervalSelector}>
            <TouchableOpacity
              style={[
                styles.intervalButton,
                selectedInterval === 'month' && styles.intervalButtonActive,
              ]}
              onPress={() => setSelectedInterval('month')}
            >
              <Text
                style={[
                  styles.intervalButtonText,
                  selectedInterval === 'month' && styles.intervalButtonTextActive,
                ]}
              >
                Monthly
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.intervalButton,
                selectedInterval === 'year' && styles.intervalButtonActive,
              ]}
              onPress={() => setSelectedInterval('year')}
            >
              <Text
                style={[
                  styles.intervalButtonText,
                  selectedInterval === 'year' && styles.intervalButtonTextActive,
                ]}
              >
                Yearly
              </Text>
              <View style={styles.saveBadge}>
                <Text style={styles.saveBadgeText}>Save 17%</Text>
              </View>
            </TouchableOpacity>
          </View>

          <View style={styles.plansContainer}>
            {filteredPlans.map((plan) => {
              const isActive = activePlan?.id === plan.id;
              const isPremiumPlan = plan.id.includes('premium');

              return (
                <View
                  key={plan.id}
                  style={[
                    styles.planCard,
                    !isPremiumPlan && styles.planCardPro,
                    isActive && styles.planCardActive,
                  ]}
                >
                  {!isPremiumPlan && (
                    <View style={styles.popularBadge}>
                      <Text style={styles.popularBadgeText}>MOST POPULAR</Text>
                    </View>
                  )}

                  <Text style={styles.planName}>{plan.name.split(' ')[0]}</Text>
                  <View style={styles.priceContainer}>
                    <Text style={styles.planPrice}>${plan.price}</Text>
                    <Text style={styles.planInterval}>/{plan.interval}</Text>
                  </View>

                  <View style={styles.featuresContainer}>
                    {plan.features.map((feature, index) => (
                      <View key={index} style={styles.featureRow}>
                        <Check size={16} color={Colors.primary.accent} />
                        <Text style={styles.featureText}>{feature}</Text>
                      </View>
                    ))}
                  </View>

                  {isActive ? (
                    <View style={styles.activeButton}>
                      <Text style={styles.activeButtonText}>Current Plan</Text>
                    </View>
                  ) : (
                    <TouchableOpacity
                      style={[
                        styles.subscribeButton,
                        !isPremiumPlan && styles.subscribeButtonPro,
                      ]}
                      onPress={() => handleSubscribe(plan.id)}
                      disabled={loading}
                    >
                      {loading ? (
                        <ActivityIndicator color={Colors.primary.bg} />
                      ) : (
                        <Text style={styles.subscribeButtonText}>Subscribe</Text>
                      )}
                    </TouchableOpacity>
                  )}
                </View>
              );
            })}
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>
              All plans include a 7-day free trial. Cancel anytime.
            </Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary.bg,
  },
  header: {
    alignItems: 'center',
    padding: 24,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '700' as const,
    color: Colors.primary.text,
    marginTop: 16,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.primary.textSecondary,
    textAlign: 'center' as const,
  },
  currentPlanCard: {
    backgroundColor: Colors.secondary.bg,
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 24,
    marginBottom: 24,
    borderWidth: 2,
    borderColor: Colors.primary.accent,
  },
  currentPlanHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  currentPlanTitle: {
    fontSize: 14,
    fontWeight: '600' as const,
    color: Colors.primary.accent,
    marginLeft: 8,
  },
  currentPlanName: {
    fontSize: 20,
    fontWeight: '700' as const,
    color: Colors.primary.text,
    marginBottom: 4,
  },
  currentPlanPrice: {
    fontSize: 16,
    color: Colors.primary.textSecondary,
    marginBottom: 8,
  },
  expiresText: {
    fontSize: 14,
    color: Colors.primary.textSecondary,
    marginBottom: 16,
  },
  cancelButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#ef4444',
    fontSize: 14,
    fontWeight: '600' as const,
  },
  intervalSelector: {
    flexDirection: 'row',
    backgroundColor: Colors.secondary.bg,
    borderRadius: 12,
    padding: 4,
    marginHorizontal: 24,
    marginBottom: 24,
  },
  intervalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    position: 'relative',
  },
  intervalButtonActive: {
    backgroundColor: Colors.primary.accent,
  },
  intervalButtonText: {
    fontSize: 14,
    fontWeight: '600' as const,
    color: Colors.primary.textSecondary,
  },
  intervalButtonTextActive: {
    color: Colors.primary.bg,
  },
  saveBadge: {
    position: 'absolute',
    top: -8,
    right: 8,
    backgroundColor: '#10b981',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  saveBadgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700' as const,
  },
  plansContainer: {
    paddingHorizontal: 24,
    gap: 16,
  },
  planCard: {
    backgroundColor: Colors.secondary.bg,
    borderRadius: 16,
    padding: 24,
    borderWidth: 2,
    borderColor: Colors.card.border,
    position: 'relative',
  },
  planCardPro: {
    borderColor: Colors.primary.accent,
  },
  planCardActive: {
    borderColor: Colors.primary.accent,
    backgroundColor: 'rgba(108, 212, 255, 0.05)',
  },
  popularBadge: {
    position: 'absolute',
    top: -12,
    left: 24,
    backgroundColor: Colors.primary.accent,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  popularBadgeText: {
    color: Colors.primary.bg,
    fontSize: 10,
    fontWeight: '700' as const,
  },
  planName: {
    fontSize: 24,
    fontWeight: '700' as const,
    color: Colors.primary.text,
    marginBottom: 8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 24,
  },
  planPrice: {
    fontSize: 36,
    fontWeight: '700' as const,
    color: Colors.primary.text,
  },
  planInterval: {
    fontSize: 16,
    color: Colors.primary.textSecondary,
    marginLeft: 4,
  },
  featuresContainer: {
    gap: 12,
    marginBottom: 24,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  featureText: {
    fontSize: 14,
    color: Colors.primary.text,
    flex: 1,
  },
  subscribeButton: {
    backgroundColor: Colors.primary.accent,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  subscribeButtonPro: {
    backgroundColor: Colors.primary.accent,
  },
  subscribeButtonText: {
    color: Colors.primary.bg,
    fontSize: 16,
    fontWeight: '600' as const,
  },
  activeButton: {
    backgroundColor: Colors.card.bg,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.card.border,
  },
  activeButtonText: {
    color: Colors.primary.text,
    fontSize: 16,
    fontWeight: '600' as const,
  },
  footer: {
    padding: 24,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    color: Colors.primary.textSecondary,
    textAlign: 'center' as const,
  },
});
