import '../models/source.dart';

/// Result of parsing an input URL or identifier into a concrete [MediaSource].
class ParsedSource {
  const ParsedSource({required this.source});
  final MediaSource source;
}

/// Strategy interface for platform-specific parsers (e.g., YouTube, Vimeo, Pornhub, M3U8).
abstract class SourceResolver {
  bool canHandle(Uri input);
  Future<ParsedSource> resolve(Uri input);
}

/// Aggregates multiple resolvers and chooses the first that can handle the URL.
class SourceParser {
  SourceParser(this._resolvers);

  final List<SourceResolver> _resolvers;

  Future<ParsedSource> parse(Uri input) async {
    for (final resolver in _resolvers) {
      if (resolver.canHandle(input)) {
        return resolver.resolve(input);
      }
    }
    // Fallback: treat as direct URL with best-effort metadata.
    return ParsedSource(
      source: MediaSource(
        id: input.toString(),
        title: input.pathSegments.isNotEmpty ? input.pathSegments.last : input.host,
        isLive: false,
        url: input,
        mimeType: null,
      ),
    );
  }
}
